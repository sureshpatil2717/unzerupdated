$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "20b972ba-96ba-4d3e-99c5-5c5ef632ccef",
    "feature": "To verify the basic functionality of Trello task management tool",
    "scenario": "verify the basic functionality of Trello task management tool",
    "start": 1660662620300,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1660662651991,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});